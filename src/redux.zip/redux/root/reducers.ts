import { combineReducers } from "redux";
import auth from "../auth/reducer";
import testResults from "../testResults/reducer"


const rootReducer = combineReducers({
  auth,
  testResults
});


export default rootReducer;
