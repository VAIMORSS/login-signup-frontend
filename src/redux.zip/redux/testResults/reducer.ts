import { TestResultsStoreType } from "../../types";
import { GET_JEMETER_TEST_RESULTS, GET_JEMETER_TEST_RESULTS_RESPONSE, GET_SINGLE_TEST_RESULT, GET_SINGLE_TEST_RESULT_RESPONSE } from "./actions";

const initialStore: TestResultsStoreType = {
    jemeter: null,
    loading: false,
    error: null,
    testResults: null
}

const getTestResults = (state: any, action: any) => {
    return {
        ...state,
        loading: true
    }
}

const getTestResultResponse = (state: any, action: any) => {
    return {
        ...state,
        loading: false,
        error: action.error,
        testResults: action.payload
    }
}

const getSingleTestResults = (state: any, action: any) => {
    return {
        ...state,
        loading: true
    }
}

const getSingleTestResultResponse = (state: any, action: any) => {
    if (action.error) {
        return {
            ...state,
            loading: false,
            error: action.error,
        }
    }
    return {
        ...state,
        loading: false,
        jemeter: { ...state.jemeter, [action.payload.id]: action.payload.jemeter },
    }
}

function reducer(state = initialStore, action: any) {
    switch (action.type) {
        case GET_JEMETER_TEST_RESULTS:
            return getTestResults(state, action);
        case GET_JEMETER_TEST_RESULTS_RESPONSE:
            return getTestResultResponse(state, action);
        case GET_SINGLE_TEST_RESULT:
            return getSingleTestResults(state, action);
        case GET_SINGLE_TEST_RESULT_RESPONSE:
            return getSingleTestResultResponse(state, action);
        default:
            return state;
    }
}

export default reducer;
