import { takeEvery } from "redux-saga/effects";
import { responseType } from "../../types";
import { api, payloadLoader } from "../../utils";
import {
    GET_JEMETER_TEST_RESULTS,
    GET_JEMETER_TEST_RESULTS_RESPONSE,
    GET_SINGLE_TEST_RESULT,
    GET_SINGLE_TEST_RESULT_RESPONSE
} from "./actions";

//TODO jemeter database add sitename and try to create form data uploader

function* getJemeterTestResults(action: any) {
    try {
        const res: responseType = yield api.testResults.getTestResults();
        yield payloadLoader({ data: res.data.data }, GET_JEMETER_TEST_RESULTS_RESPONSE);
    } catch (e) {
        yield payloadLoader({ error: e }, GET_JEMETER_TEST_RESULTS_RESPONSE);
    }
}

function* getSingleJemeterTestResults(action: any) {
    try {
        const res: responseType = yield api.testResults.getTestResultById(action.id);
        yield payloadLoader({ data: res.data }, GET_SINGLE_TEST_RESULT_RESPONSE);
    } catch (e) {
        yield payloadLoader({ error: e }, GET_SINGLE_TEST_RESULT_RESPONSE);
    }
}

function* authSagaWatcher() {
    yield takeEvery(GET_JEMETER_TEST_RESULTS, getJemeterTestResults);
    yield takeEvery(GET_SINGLE_TEST_RESULT, getSingleJemeterTestResults);
}

export default authSagaWatcher;