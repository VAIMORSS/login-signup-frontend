export const GET_JWT = "GET_JWT";
export const GET_JWT_RESULT = "GET_JWT_RESULT";
export const LOG_OUT = "LOG_OUT";
