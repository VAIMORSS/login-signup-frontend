import { put, takeEvery } from "redux-saga/effects";
import { responseType } from "../../types";
import { api } from "../../utils";
import { GET_JWT, GET_JWT_RESULT } from "./actions";

function* getJWT(action: any) {
  let token = localStorage.getItem("bearer");
  if (!token) {
    let res: responseType = yield api.auth.getJwtToken({
      strategy: "local", ...action.user
    })
    if (res.error) {
      yield put({ error: res.error, type: GET_JWT_RESULT })
      return;
    }
    token = res.data.accessToken;
    localStorage.setItem("bearer", res.data.accessToken);
  }
  yield put({ data: token, type: GET_JWT_RESULT })
  return;
}



function* authSagaWatcher() {
  yield takeEvery(GET_JWT, getJWT);
}

export default authSagaWatcher;
